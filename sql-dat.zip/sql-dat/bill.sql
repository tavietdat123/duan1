-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 01, 2022 lúc 11:59 AM
-- Phiên bản máy phục vụ: 10.4.24-MariaDB
-- Phiên bản PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `duan1`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill`
--

CREATE TABLE `bill` (
  `id` int(11) NOT NULL,
  `pointOfDeparture` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `dateTime` datetime NOT NULL,
  `price` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `company_img` varchar(255) NOT NULL,
  `type_ticket_id` int(11) NOT NULL,
  `round_trip` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `flight_code` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tell` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `booking_date` varchar(255) NOT NULL,
  `pay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `bill`
--

INSERT INTO `bill` (`id`, `pointOfDeparture`, `destination`, `dateTime`, `price`, `company`, `company_img`, `type_ticket_id`, `round_trip`, `quantity`, `flight_code`, `fullName`, `name`, `tell`, `email`, `booking_date`, `pay`) VALUES
(1, 'hà nội', 'hồ chí minh', '2022-12-04 00:00:00', 2500, 'VIETNAMELINE', 'VN.png', 2, 1, 5, '123456', 'Ta viet dat', 'Ông', 962205532, 'datxz2003@gmail.com', '0000-00-00 00:00:00', 2),
(2, 'hà nội', 'hồ chí minh', '2022-12-04 00:00:00', 1200, 'VIETJET', 'VJ.png', 1, 1, 4, '123124', 'Ta viet dat', 'Ông', 928174473, 'datxz2003@gmail.com', '2022-12-01 11:54:57am', 2);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
